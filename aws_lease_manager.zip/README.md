# lease_manager
Manages AWS leases..

Setup requires changes in the tableName
